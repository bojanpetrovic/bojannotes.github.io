import Config

config :playground, Playground.Repo,
  database: "ecto_playground_associations",
  username: "postgres",
  password: "postgres",
  hostname: "localhost"

config :playground, ecto_repos: [Playground.Repo]
