defmodule Playground.Post do
  use Ecto.Schema

  alias Playground.Author


  schema "posts" do
    field :title, :string
    field :category, :string
    field :published_at, :utc_datetime

    has_many :authors, Author
  end
end
