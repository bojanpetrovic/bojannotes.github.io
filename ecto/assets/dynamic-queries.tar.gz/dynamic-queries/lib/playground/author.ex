defmodule Playground.Author do
  use Ecto.Schema

  alias Playground.Post

  schema "authors" do
    field :name, :string

    belongs_to :post, Post
  end
end
