defmodule Playground do
  alias Playground.Author
  alias Playground.Post
  alias Playground.Repo

  import Ecto.Query

  def run do
    prepare()

    params = %{
      "order_by" => "published_at",
      "author" => "bill"
    }

    filter(params)
    |> Repo.all()
    |> IO.inspect

    clear()
  end

  def filter(params) do
    Post
    |> join(:inner, [p], a in assoc(p, :authors), as: :authors)
    |> order_by(^filter_order_by(params["order_by"]))
    |> where(^filter_where(params))
    |> preload([p, a], [authors: a])
  end

  def filter_order_by("published_at_desc"),
    do: [desc: dynamic([p], p.published_at)]

  def filter_order_by("published_at"),
    do: dynamic([p], p.published_at)

  def filter_order_by("author_name_desc"),
    do: [desc: dynamic([authors: a], a.name)]

  def filter_order_by("author_name"),
    do: dynamic([authors: a], a.name)

  def filter_order_by(_),
    do: []

  def filter_where(params) do
    Enum.reduce(params, dynamic(true), fn
      {"author", value}, dynamic ->
        dynamic([authors: a], ^dynamic and a.name == ^value)

      {"category", value}, dynamic ->
        dynamic([p], ^dynamic and p.category == ^value)

      {"published_at", value}, dynamic ->
        dynamic([p], ^dynamic and p.published_at > ^value)

      {_, _}, dynamic ->
        # Not a where parameter
        dynamic
    end)
  end

  defp prepare() do

    %Post{
      category: "comedy",
      title: "something strange",
      published_at: ~U[2020-05-31 20:30:31Z],
      authors: [
        %Author{name: "john"},
        %Author{name: "eric"},
      ]
    }
    |> Repo.insert!()

    %Post{
      category: "comedy",
      title: "can't believe it",
      published_at: ~U[2020-05-31 20:31:31Z],
      authors: [
        %Author{name: "bill"},
        %Author{name: "simon"},
      ]
    }
    |> Repo.insert!()

  end

  defp clear() do
    Repo.delete_all(Author)
    Repo.delete_all(Post)
  end
end
