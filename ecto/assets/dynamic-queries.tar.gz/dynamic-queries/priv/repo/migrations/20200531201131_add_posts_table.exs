defmodule Playground.Repo.Migrations.AddPostsTable do
  use Ecto.Migration

  def change do
    create table(:posts) do
      add :title, :string
      add :category, :string
      add :published_at, :utc_datetime
    end
  end
end
