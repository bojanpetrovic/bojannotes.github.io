defmodule Playground.Repo.Migrations.AddAuthorsTable do
  use Ecto.Migration

  def change do
    create table(:authors) do
      add :name, :string

      add :post_id, references(:posts), null: false
    end
  end
end
