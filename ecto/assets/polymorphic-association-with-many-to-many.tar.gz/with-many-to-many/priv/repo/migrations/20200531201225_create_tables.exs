defmodule Playground.Repo.Migrations.AddAuthorsTable do
  use Ecto.Migration

  def change do
    create table(:todo_lists) do
      add :title, :string
      timestamps()
    end

    create table(:projects) do
      add :name, :string
      timestamps()
    end

    create table(:todo_items) do
      add :description, :string
      timestamps()
    end

    create table(:todo_list_items) do
      add :todo_item_id, references(:todo_items, on_delete: :delete_all)
      add :todo_list_id, references(:todo_lists, on_delete: :delete_all)
    end

    create table(:project_items) do
      add :todo_item_id, references(:todo_items, on_delete: :delete_all)
      add :project_id, references(:projects, on_delete: :delete_all)
    end
  end
end
