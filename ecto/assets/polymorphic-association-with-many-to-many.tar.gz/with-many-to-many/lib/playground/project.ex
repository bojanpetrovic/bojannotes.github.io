defmodule Playground.Project do
  use Ecto.Schema

  schema "projects" do
    field :name
    many_to_many :todo_items, Playground.TodoItem,
      join_through: "project_items"
    timestamps()
  end

  def changeset(struct, params \\ %{}) do
    struct
    |> Ecto.Changeset.cast(params, [:name])
    |> Ecto.Changeset.cast_assoc(
      :todo_items,
      required: true
    )
  end
end
