defmodule Playground do
  import Ecto.Query
  alias Playground.Repo
  alias Playground.TodoList
  alias Playground.Project
  alias Playground.TodoItem

  def run do
    prepare()

    # Create todo list tasks
    todo_list_params = %{
      "title" => "shipping list",
      "todo_items" => %{
        0 => %{"description" => "bread"},
        1 => %{"description" => "eggs"}
      }
    }

    %TodoList{}
    |> TodoList.changeset(todo_list_params)
    |> Repo.insert()

    # Create projects tasks
    project_params = %{
      "name" => "Dotted Line",
      "todo_items" => %{
        0 => %{"description" => "one task"},
        1 => %{"description" => "two task "}
      }
    }

    %Project{}
    |> Project.changeset(project_params)
    |> Repo.insert()

    # Get all tasks
    TodoItem
    |> Repo.all()
    |> IO.inspect

    # Get all projects with tasks
    Project
    |> Repo.all()
    |> Repo.preload(:todo_items)
    |> IO.inspect

    clear()
  end

  defp prepare() do
  end

  defp clear() do
    Project |> Repo.delete_all()
    TodoList |> Repo.delete_all()
    TodoItem |> Repo.delete_all()

  end
end
